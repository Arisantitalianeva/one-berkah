-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 15 Jul 2015 pada 07.36
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sp_motormatic`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_injeksi`
--

CREATE TABLE IF NOT EXISTS `diagnosa_injeksi` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_injeksi`
--

INSERT INTO `diagnosa_injeksi` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus1.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 2, 3, 'Y', 'N'),
(2, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 3, 0, 'Y', 'N'),
(3, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y'),
(4, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 4, 4, 'N', 'Y'),
(5, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 6, 7, 'Y', 'N'),
(6, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 7, 4, 'Y', 'N'),
(7, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 4, 4, 'N', 'Y'),
(8, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 8, 8, 'N', 'Y'),
(9, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 10, 11, 'Y', 'N'),
(10, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 11, 8, 'Y', 'N'),
(11, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 8, 8, 'N', 'Y');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

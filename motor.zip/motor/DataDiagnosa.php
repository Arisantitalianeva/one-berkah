<html>
	
<p>&nbsp;</p>
<center>
<p><img src="matic club.png" width="425" height="273"></p>
</center>
 <?php 
include("koneksi.php"); 
echo "<CENTER><H1></H1></CENTER>"; 
echo "<a class='btn  btn-block btn-large	' href='diagnosa_umum.php?idpertanyaan=1'>Mulai Diagnosa</a>"; 
//echo "<a class='btn  btn-block btn-large	' href='?page=diagnosa_umum'>Mulai Diagnosa</a>"; 
echo '<br>';
echo '<br>';
echo '</br><div >
</div>';
?>
</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
</html>

<?php
@session_start();
if (!isset($_SESSION['username_pengguna'])){
    echo "<div align=center><b> PERHATIAN! </b><br>";
	echo "AKSES DITOLAK, PENGGUNA BELUM LOGIN</div>";
	echo '<meta http-equiv="refresh" content="0;url=../?page=loginuser">';
	exit;
}
?>
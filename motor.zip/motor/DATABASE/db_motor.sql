-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 02 Agu 2015 pada 15.19
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sp_motormatic`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_digital_spedometer`
--

CREATE TABLE IF NOT EXISTS `diagnosa_digital_spedometer` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_digital_spedometer`
--

INSERT INTO `diagnosa_digital_spedometer` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada digital_spedometer, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Lampu Ornament / Background Mati.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Sensor Bensin Mati.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Jarum Spedometer Mati.?', 4, 0, 'Y', 'N'),
(4, 'Kerusakan Pada digital_spedometer, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusidigital_spedometer.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_eletric_stater`
--

CREATE TABLE IF NOT EXISTS `diagnosa_eletric_stater` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_eletric_stater`
--

INSERT INTO `diagnosa_eletric_stater` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada eletric_stater, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah saat dihidupkan gengan electric stater tidak berbunyi.?', 2, 0, 'Y', 'N'),
(2, 'Apakah stater berbunyi, tetapi tidak mau berputar.?', 3, 0, 'Y', 'N'),
(3, 'Apakah suara dinamo stater kasar.?', 4, 0, 'Y', 'N'),
(4, 'Apakah suara dinamo panas.?', 5, 0, 'Y', 'N'),
(5, 'Kerusakan Pada eletric_stater, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusielectric_stater.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_fanbel`
--

CREATE TABLE IF NOT EXISTS `diagnosa_fanbel` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_fanbel`
--

INSERT INTO `diagnosa_fanbel` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada fanbel, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Tenaga Yang Dihasilkan Lemah.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Mesin Tersendat-Sendat Saat Berjalan.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Suara Berderit.?', 4, 0, 'Y', 'N'),
(4, 'Kerusakan Pada fanbel, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusifanbel.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_injeksi`
--

CREATE TABLE IF NOT EXISTS `diagnosa_injeksi` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_injeksi`
--

INSERT INTO `diagnosa_injeksi` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus1.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 2, 3, 'Y', 'N'),
(2, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 3, 0, 'Y', 'N'),
(3, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y'),
(4, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 4, 4, 'N', 'Y'),
(5, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 6, 7, 'Y', 'N'),
(6, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 7, 4, 'Y', 'N'),
(7, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 4, 4, 'N', 'Y'),
(8, 'Kerusakan Bukan Pada injeksi, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 8, 8, 'N', 'Y'),
(9, 'Apakah Lampu injeksi pada spedometer  menyala selama 2 detik dan akan mati (kalibrasi).?', 10, 11, 'Y', 'N'),
(10, 'Apakah Lampu injeksi pada spedometer memunculkan kedipan lain.?', 11, 8, 'Y', 'N'),
(11, 'Kerusakan Pada injeksi, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiinjeksi.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 8, 8, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_klep`
--

CREATE TABLE IF NOT EXISTS `diagnosa_klep` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_klep`
--

INSERT INTO `diagnosa_klep` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada klep, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Mesin Sulit Dihidupkan.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Mesin Tidak Stasioner.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Keluar Asap Putih Pada Kenalpot.?', 4, 0, 'Y', 'N'),
(4, 'Apakah Bahan Bakar Boros.?', 5, 0, 'Y', 'N'),
(5, 'Apakah Oli Cepat Habis.?', 6, 0, 'Y', 'N'),
(6, 'Kerusakan Pada klep, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiklep.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_klep1`
--

CREATE TABLE IF NOT EXISTS `diagnosa_klep1` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_klep1`
--

INSERT INTO `diagnosa_klep1` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada klep1, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus1.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Mesin Sulit Dihidupkan.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Mesin Tidak Stasioner.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Keluar Asap Putih Pada Kenalpot.?', 4, 0, 'Y', 'N'),
(4, 'Apakah Bahan Bakar Boros.?', 5, 0, 'Y', 'N'),
(5, 'Apakah Oli Cepat Habis.?', 6, 0, 'Y', 'N'),
(6, 'Kerusakan Pada klep1, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusiklep1.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_piston`
--

CREATE TABLE IF NOT EXISTS `diagnosa_piston` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_piston`
--

INSERT INTO `diagnosa_piston` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada Piston, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Mesin Sulit Dihidupkan.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Tenaga Yang Dihasilkan Lemah.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Mesin Cepat Panas.?', 4, 0, 'Y', 'N'),
(4, 'Apakah Busi Mudah Mati.?', 5, 0, 'Y', 'N'),
(5, 'Apakah Keluar Asap Putih Pada Kenalpot.?', 6, 0, 'Y', 'N'),
(6, 'Apakah Suara Kasar Pada Kepala Silinder.?', 7, 0, 'Y', 'N'),
(7, 'Apakah Oli Cepat Habis.?', 8, 0, 'Y', 'N'),
(8, 'Kerusakan Pada Piston, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusipiston.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_piston1`
--

CREATE TABLE IF NOT EXISTS `diagnosa_piston1` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_piston1`
--

INSERT INTO `diagnosa_piston1` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada Piston, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus1.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Mesin Sulit Dihidupkan.?', 2, 0, 'Y', 'N'),
(2, 'Apakah Tenaga Yang Dihasilkan Lemah.?', 3, 0, 'Y', 'N'),
(3, 'Apakah Mesin Cepat Panas.?', 4, 0, 'Y', 'N'),
(4, 'Apakah Busi Mudah Mati.?', 5, 0, 'Y', 'N'),
(5, 'Apakah Keluar Asap Putih Pada Kenalpot.?', 6, 0, 'Y', 'N'),
(6, 'Apakah Suara Kasar Pada Kepala Silinder.?', 7, 0, 'Y', 'N'),
(7, 'Apakah Oli Cepat Habis.?', 8, 0, 'Y', 'N'),
(8, 'Kerusakan Pada Piston, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusipiston.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_rem`
--

CREATE TABLE IF NOT EXISTS `diagnosa_rem` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_rem`
--

INSERT INTO `diagnosa_rem` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'Kerusakan Bukan Pada rem, Silahkan Cek Diagnosa Lain </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> KEMBALI DIAGNOSA </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah tenaga yang dihasikan tidak seperti biasanya, lebih lambat/lebih cepat.?', 2, 0, 'Y', 'N'),
(2, 'Apakah pada saat direm tidak ada respon.?', 3, 0, 'Y', 'N'),
(3, 'Apakah suara berderit pada rem.?', 4, 0, 'Y', 'N'),
(4, 'Kerusakan Pada rem, Silahkan Cek Solusi Perbaikan</h3></br></br>  <a href=''Solusirem.php'' class=''btn btn-success btn-large btn-block'' /> SOLUSI </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_umum`
--

CREATE TABLE IF NOT EXISTS `diagnosa_umum` (
  `ID` int(11) NOT NULL,
  `solusi_dan_pertanyaan` varchar(500) NOT NULL,
  `bila_benar` int(11) NOT NULL,
  `bila_salah` int(11) NOT NULL,
  `mulai` char(1) NOT NULL,
  `selesai` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_umum`
--

INSERT INTO `diagnosa_umum` (`ID`, `solusi_dan_pertanyaan`, `bila_benar`, `bila_salah`, `mulai`, `selesai`) VALUES
(0, 'LANJUTKAN DIAGNOSA KERUSAKAN </h3></br></br>  <a href=''diagnosakhusus3.php'' class=''btn btn-success btn-large btn-block'' /> DIAGNOSA KHUSUS </a>', 0, 0, 'N', 'Y'),
(1, 'Apakah Motor Matic Anda Dapat Dihidupkan Baik Stater Maupun Manual', 2, 0, 'Y', 'N'),
(2, 'Apakah Sulit Untuk Menghidupkan Mesin Baik Menggunakan Starter Maupun Manual..?', 0, 3, 'Y', 'N'),
(3, 'Apakah Setelah Dihidupkan Mesin Kemudian Mati Dan Sulit Untuk Hidup Kembali..?', 4, 5, 'Y', 'N'),
(4, 'LANJUTKAN DIAGNOSA KERUSAKAN </h3></br></br>  <a href=''diagnosakhusus1.php'' class=''btn btn-success btn-large btn-block'' /> DIAGNOSA KHUSUS </a>', 0, 0, 'N', 'Y'),
(5, 'LANJUTKAN DIAGNOSA KERUSAKAN </h3></br></br>  <a href=''diagnosakhusus2.php'' class=''btn btn-success btn-large btn-block'' /> DIAGNOSA KHUSUS </a>', 0, 0, 'N', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id_log` int(11) NOT NULL,
  `id_pengguna` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id_pages` int(2) NOT NULL,
  `tipe` varchar(100) NOT NULL,
  `isi` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pages`
--

INSERT INTO `pages` (`id_pages`, `tipe`, `isi`) VALUES
(1, 'site_home', '<h3><b><p>MOTOR MATIC &nbsp;</p></b></h3>\r\n<img width=200 height=260 src=''images/home.png'' />\r\n<p> Transmisi pada motor matic adalah transmisi tanpa perpindahan roda gigi, jadi menggunakan pulley dan belt. Istilah Kerennya CVT (Continue Variable Transmision)\r\nCVT (Continue Variable Transmision) adalah suatu sistem penyalur tenaga secara otomatis dengan bantuan gaya sentrifugal(gaya dorong yang disebabkan oleh putaran).\r\n&nbsp;</p>\r\n<b><p> KOMPONEN SISTEM TRANSMISI MATIK PADA HONDA &nbsp;</p></b>\r\nPerlu diketahui komponen perbedaan pada transmisi manual dan matik sangatlah berbeda oleh karena itu inilah antara lain gambaran transmisi otomatis yang biasa disebut transmisi matik....&nbsp;</p>\r\n<b><p>CARA KERJA CVT &nbsp;</p></b>\r\n<p> Putaran bawah (stationer) diameter yang dibentuk puley primer (drive pulley*) lebih kecil dibanding puley sekunder (driven pulley**) sehingga terjadi ratio yang ringan. \r\nSaat putaran menengah diameter puley primer membentuk lingkaran yang sama besar dengan puley sekunder. hal ini terjadi karena gaya sentrifugal menyebabkan kedua dinding puley primer semakin sempit. Prosis ini akan terus berlanjut seiring putaran mesin yang semakin meningkat sehingga saat putaran atas diameter yang dibentuk puley primer lebih besar daripada puley sekunder. &nbsp;</p>\r\n* drive pulley = Pulley yang terhubung dengan crankshaft (mesinnya)&nbsp;</p>\r\n** driven pulley = Pulley yang terhubung ke roda motor&nbsp;</p>\r\n<p> Sebenarnya, dasar pemikiran CVT berasal dari sepeda. Pada sistem percepatan sepeda, apabila gear di bagian depan kecil dan gear yang dibelakang besar, maka sepeda akan berjalan lambat. Seperti gigi 1 pada kendaraan, begitu juga sebaliknya. Nah, sistem ini lah yang di adopsi oleh CVT. \r\nNamun, bedanya CVT menggunakan sabuk yang sangat kuat dan gear diganti dengan pulley yang bisa membesar dan mengecil tergantung dengan gaya sentrifugal yang diterima pulley. &nbsp;</p>\r\n&nbsp;</p>\r\n<b><p> JENIS-JENIS KONTRUKSI MATIK &nbsp;</p></b>\r\n<p> Pada metic CVT umumnya keluar dari kruk as di gear box sebelah kanan adalah ruang untuk rumah kopling sentrifugal. Sedang pada CV Matic dan YCAT ruang ini dijadikan ruang untuk CVT. Bentuknya memang tak sepanjang CVT pada skutik, dengan pully berdiameter lebih besar. Baru dari driven pully (pully belakang) terhubung ke final gear dan rantai yang meneruskan transfer tenaga ke roda. &nbsp;</p>\r\nNah yang membedakan diantara CV matic dan YCAT adalah konstruksi pendinginannya di CVT. Keduanya sama-sama memiliki lubang masuk udara di drive pully (pully depan), namun pada YCAT dilengkapi dengan belalai yang moncongnya terletak di sebelah filter udara. &nbsp;</p>\r\n<p> Sedang CV matic belum menjelaskan posisi lubang masuknya udara, hanya ada lubang di atas drive pully. Sedang tempat keluarnya udara yang telah melewati CVT sama-sama di atas driven pully. &nbsp;</p>\r\n<b><p> KEUNTUNGAN CVT &nbsp;</p></b>\r\n<p> Bisa mendongkrak performa mesin / mobil secara keseluruhan karena dengan rasio 2gigi2 tak terbatas maka akan selalu pada 2rasio gigi yang tepat2 sehingga tenaga tetap terjamin optimal.\r\nDengan rasio gigi tidak terbatas, maka akan terasa nyaman untuk cruising, sehingga bisa lebih irit dan mengurangi emisi gas buang. Bayangkan kalau anda ke luar kota dan di jalan tol dengan kecepatan konstant, lebih irit bukan.\r\nSelain pengoperasiannya mudah. perawatannya juga relatif murah. Yang perlu diperhatikan kondisi sabuk (V-BELT) harus selalu diperiksa setiap 20.000 km. Tergantung cara pemakaian dan kondisi medan jalan. Jika V-BELT sudah retak-retak atau memanjang maka sebaiknya diganti baru. &nbsp; </p>\r\n'),
(2, 'site_help', '<b><p>- Menu Home, berisi informasi tentang Motor Matic. &nbsp;</p></b>\r\n 	\r\n\r\n<b><p>- Menu Diagnosa, berisi langkah-langkah untuk mendiagnosa Kerusakan Motor Matic, Disini terdapat langkah-langkahnya sebagai berikut : &nbsp;</p></b>\r\n<p> 1.	Pengguna mendaftar dengan mengisi form yang telah tersedia dengan memasukkan\r\n<p> 2.	Selanjutnya, pengguna akan diarahkan ke menu diagnosa kerusakan motor dengan memilih salah satu gejala kerusakan umum untuk awal atau dugaan, lalu klik lanjut.&nbsp;</p>\r\n<p> 3.  Kemudian tampil ke menu diagnosa khusus guna menyimpulkan kerusakan secara detail Klik proses. &nbsp;</p>\r\n<p> 4.  Aplikasi akan menampilkan hasil dari diagnosa sebelumnya, bagian Kerusakan Dan Solusinya.&nbsp;</p>\r\n<b><p> - Menu Artikel, berisi tentang artikel  Tips Dan trik motor Matik.&nbsp;</p>\r\n\r\n<p> - Menu Profil, berisi tentang pembuat aplikasi diagnosa kerusakan Motor Matic.&nbsp;</p>\r\n\r\n<p> - Menu Admin, berisi halaman untuk masuk ke menu admin, dengan memasukkan nama user dan kata kunci admin.&nbsp;</p>\r\n 	\r\n<p> - Menu Bantuan, berisi tentang bantuan menggunakan aplikasi diagnosa Keruskan Motor Matic.&nbsp;</p></b>'),
(3, 'Site_profil', '<b>\r\n<p>Â </p>\r\n<p>Nama : Â </p>\r\n<p>NIM : Â </p>\r\n<p>Usia : 23 Tahun Â </p>\r\n<p>Alamat : Thehok,Jambi Â </p>\r\n<p>Jenis Kelamin : Laki-Laki Â </p>\r\n</b>'),
(4, 'artikel', '<b><h3><p> Beberapa cara merawat mesin motor matic :  &nbsp;</p></b></h3>\r\n \r\n<p> - Selalu memanaskan mesin motor sebelum digunakan &nbsp;</p>\r\n<p> - Servis secara berkala dan selalu cek oli &nbsp;</p>\r\n<p> - Perhatikan hal-hal yang kelihatanya remeh tapi sebenarnya vital. \r\n  Hal remeh disini misalnya V-belt,Roller,Klep atau lainya. &nbsp;</p>\r\n<p> - Ganti oli Shok secara teratur &nbsp;</p>\r\n<p> - Cuci dengan air tawar &nbsp;</p>\r\n<p> - Gunakan suku cadang yang asli. &nbsp;</p>'),
(5, 'solusipiston', '<h3><b><p>GEJALA KERUSAKAN PADA KEPALA SILINDER, SILINDER DAN PISTON &nbsp;</p></b></h3>\r\n<img width=200 height=260 src=''images/piston.jpg'' />\r\n<b><p> Gejala Kerusakan : Tekanan Kompressi Rendah </p></b>\r\n<p> Kemungkinan Penyebab dan Langkah Perbaikan :</p>\r\n<p> Penyetelan pembukaan pada katup tidak tepat. Buka tutup katup masuk dan dan katup buang dan stel pembukaan katup sesuai dengan standard.\r\nKatup aus / bengkok. Jika katup aus atau bengkok gantilah katup dengan yang baru sesuai dengan standard.\r\nPegas katup patah. Jika pegas katup patah, gantilah pegas dengan yang baru.\r\nKepala silinder berubah bentuk atau rusak. Jika terjadi hal demikian gantilah kepala silinder.\r\nDinding silinder aus. Perbaiki dengan menambah oversize, ganti piston dan ring piston sesuai oversize yang baru atau ganti dinding silinder.\r\nPiston dan ring piston aus. Jika terjadi hal demikian ganti piston dan ring piston. &nbsp;</p>\r\n\r\n<b><p> Gejala Kerusakan : Tekanan Kompressi Terlalu Tinggi. &nbsp;</p></b>\r\n<p> Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p> Terjadi / terdapat endapan kotoran diruang bakar. Buka kepala silinder dan bersihkan kepala silinder dari endapan / kotoran. &nbsp;</p>\r\n\r\n<b><p> Gejala Kerusakan : Suara Mesin Berisik. &nbsp;</p></b>\r\n<p> Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p> Penyetelan katup tidak tepat. Buka tutup katup dan katup buang lalu setel katup dengan benar.\r\nCam shaft dan rocker arm aus. Perbaiki roker arm dan cam shaft atau ganti dengan yanng baru.\r\nSistem Tensioner rantai mesin rusak / aus. Gantilah tensioner rantai mesin dengan yang baru.\r\nGigi sprocket aus. Ganti gigi sprocket dengan yang baru.\r\nDudukan cam shaft dan roker arm aus. Gantilah dudukan tersebut dengan yang baru. &nbsp;</p>\r\n\r\n<b><p> Gejala Kerusakan : Mesin Tidak Dapat stasioner. &nbsp;</p></b>\r\n<p> Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p> Katup meunutp tidak duduk atau rapat. Buka sistem katup dan diskir katup hingga menutup dengan duduk atau rapat.\r\nPenyetelan katup tidak tepat. Setel pembukaan katup sesuai dengan standard.\r\nInsulator bocor. Gantilah insulator atau perbaiki jika masih dapat diperbaiki. &nbsp;</p>\r\n\r\n<b><p> Gejala Kerusakan : Asap Knalpot (gas sisa pembakaran) Banyak. &nbsp;</p></b>\r\n<p> Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p> Silinder, ring dan piston aus. Perbaiki dengan menambah oversize silinder, ring dan piston ganti yang baru sesuai oversize.\r\nSeal katup rusak. Gantilah seal katup jika terdapat kerusakan.\r\n<p> Gasket kepala silinder bocor. Gatilah gasket dengan yang baru dan pengencangan baut kepala sillinder sesuai dengan standard. &nbsp;</p>'),
(6, 'solusirem', '<h3><b><p>GEJALA KERUSAKAN PADA REM &nbsp;</p></b></h3>\r\n<img width=200 height=260 src=''images/rem.jpg'' />\r\n<b><p>Gejala Kerusakan : Daya pengereman kurang (jenis tromol)</p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p>Penyetelan handle rem tidak tepat. Setel handle rem jika tidak tepat.&nbsp;</p>\r\nSepatu rem kotor. Bersihkan kotoran dengan amplas atau ganti sepatu rem tromol.\r\nSepatu rem aus. Ganti sepatu rem sesuai standard.\r\nPemasangan lengan rem tidak benar. Perbaiki pemasangan lengan rem hingga benar.&nbsp;</p>\r\n\r\n<b><p>Gejala Kerusakan : Daya pengereman kurang (jenis ckram) </p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan :&nbsp;</p>\r\n<p>Piringan rem berminyak. Bersihkan piringan rem yang berminyak hingga bersih.&nbsp;</p>\r\nPad dan kampas rem kotor. Bersihkan pad dan kampas rem dari kotoran, ganti jika perlu.\r\nTerdapat udara dalam saluram minyak rem. Lakukan bleeding hingga udara hilang dari saluran minyak rem.&nbsp;</p>\r\n\r\n<b><p>Gejala Kerusakan : Handle rem terlalu keras. </p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan :&nbsp;</p>\r\n<p>Kabel rem kotor. Beri pelumas pada kabel rem.&nbsp;</p>\r\nJarak kebebasan handle rem tidak rata. setel jarak kebebasan handle rem hingga rata.\r\nKaliper dan pin rem kotor. Bersihkan kaliper dan pin rem yang kotor.&nbsp;</p>\r\n'),
(7, 'solusifanbel', '<h3><b><p>GEJALA KERUSAKAN PADA FANBELT</p></b></h3>\r\n<img width=200 height=260 src=''images/fanbelt.png'' />\r\n<b><p>Gejala Kerusakan : Fanbelt (talikipas) kering &nbsp;</p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p>karena sudah tua atau lama penggunaannya\r\nsilahkan memberi minyak pada bagian fanbelt atau lebih baik diganti dengan yang baru &nbsp;</p>\r\n\r\n<b><p>Gejala Kerusakan : Fanbelt (talikipas) Longgar &nbsp;</p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p>karena sudah tua atau lama penggunaannya\r\nsilahkan mengencangkan bagian fanbelt atau lebih baik diganti dengan yang baru &nbsp;</p>\r\n\r\n<b><p>Gejala Kerusakan : Fanbelt (talikipas) retak &nbsp;</p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p>Silahkan membeli fanbelt yang baru karena bila terus menggunakan fanbelt bisa putus dan akan lebih berakibat fatal &nbsp;</p>'),
(8, 'solusiklep', '<h3><b><p>GEJALA KERUSAKAN PADA KLEP<p></b></h3>\r\n<img width=200 height=260 src=''images/klep.png'' />\r\n<b><p>Gejala Kerusakan : Klep &nbsp;</p></b>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan :  &nbsp;</p>\r\n<p>1. Buka tutup klep atau bebaskan piston Langkah pertama adalah membuka kedua tutup klep in (aliran masuk) dan ex (aliran keluar). Bila motor Anda adalah motor varian bebek, umumnya menggunakan kunci ring 17 dan varian sport ring 24. Kemudian, posisikan klep pada posisi bebas atau posisikan piston di Titik Mati Atas (TMA). Caranya, bukalah tutup magnet pada blok mesin sebelah kiri dengan obeng minus dan pada saat bersamaan putar poros engkol dengan arah berlawanan dengan gerak jarum jam. Perhatikan lubang kecil di blok magnet dan posisikan tanda T pada garis lurus di lubang kecil tersebut. Pastikan kedua klep telah dalam posisi bebas. &nbsp;</p>\r\n<p>2. Lakukan penyetelan ukuran celah klep Bila langkah pertama telah selesai Anda lakukan, langkah selanjutnya adalah menyetel celah klep. Caranya, kendurkan baut setelan klep dengan menggunakan kunci ring yang sesuai. Bila telah kendur, kemudian atur ukuran celah klep. Ukuran celah tersebut harus mengikuti standar pabrikan yang ada selama ini sehingga Anda tidak bisa melakukannya sesuka hati. Pada umumnya, para mekanik menggunakan patokan sebagai berikut: untuk motor bebek, umumnya ukuran celah aliran masuk 0,05 milimeter (mm). Varian skuter matik celah aliran masuk 0,15 mm dan celah aliran keluar 0,26 mm. Adapun untuk varian motor sport, umumnya para mekanik menggunakan ukuran celah 0,10 mm. Bila pengaturan tersebut telah dilakukan, kembalikan posisi setelan klep. "Ukuran itu sangat menentukan besar kecilnya semburan bahan bakar," jelas Hendri. Namun, sebelumnya, posisikan fuller gauge sesuai ukuran celah klep di ujung batang klep. Setelah posisi tersebut dirasa tepat, kemudian kencangkan baut stelan klep hingga terasa kencang atau seret dan tidak goyang. Penyetelan pun selesai. </p>'),
(9, 'solusielectric_stater', '<h3><b><p>GEJALA KERUSAKAN PADA ELECTRIC STATER</b></h3>\r\n<img width=200 height=260 src=''images/stater.png'' />\r\n<p>Gejala Kerusakan : Susah dihidupkan Saat di starter &nbsp;</p>\r\n<p>Kemungkinan Penyebab dan Langkah Perbaikan : &nbsp;</p>\r\n<p>Bahan bakar kotor, jika bensin kotor maka gantilah bensin dan jangan perlu diperhatikan jangan membeli bahan bakar di pedagang eceren.\r\nCara kerja choke tidak benar. Jika cara kerja tidak benar perbaiki sistem kerja choke sesuai dengan prosedur.\r\nPutaran stasioner terlalu rendah. Setel dan tinggikan putaran stasioner sesuai putaran mesin.\r\nPenyetelan skrup udara pada karburator tidak tepat. Ulangi penyetetelan skrup udara karburator sampai memdapatkan campuran yang tepat.\r\nInsulator karburator bocor. Gantilah insulator.&nbsp;</p>'),
(10, 'solusispeedometer', '<h3><b><p>GEJALA KERUSAKAN PADA DIGITAL SPEDOMETER</p></b></h3>\r\n<img width=200 height=260 src=''images/spedometer.png'' />\r\n<b><p>Gejala dan Solusi Kerusakan : Digital Spedometer &nbsp;</p></b>\r\n<p> 1. Aki. Tidak mungkin bergerak kalau aki sedang soak, atau kendaraan tidak ada aki. Lain soal, arus listrik langsung disambungkan dari spul lampu. Ciri-ciri melihat aki atau baterai sudah lemah sangat mudah, tinggal cek "kesehatan" bunyi klakson atau tekan tombol starter )kalau ada). &nbsp;</p>\r\n\r\n<p> 2. Pelampung. Setelah dipastikan aki masih sehat, berlaih ke pelampung. Coba cek dengan membuka jok, di sebelah tutup bensin biasanya ada semacam besi dengan kabel yang direkatkan ke bodi dengan baut.\r\nBuka peranti itu, cukup menggunakan obeng plus. Lepas soketnya, dan sambungkan dua kabel yang menganga (bisa pakai jumper atau penghantar listrik lain). Setelah disambungkan, jika jarum di speedometer bergerak, berarti pelampung bermasalah.\r\n"Biasanya switch yang ada di pelampung mulai renggang karena terlalu sering terkena tekanan ketika bensin dikucurkan saat mengisi di SPBU. Banyak yang berusaha mengakalinya dengan mengikat, atau menambahkan cincin. Tapi tidak disarankan, karena cepat rusak lagi. Mending beli baru. &nbsp;</p>\r\n\r\n<p> 3. Kelistrikan. Cek jalur kabel yang menggerakkan jarum. Skemanya, dari aki menuju sekering, diurut lagi ke kunci kontak, indikator jarum/ speedometer, dan kembali lagi menuju daerah pelampung. Tes dengan alat pengukur arus, jika ada yang tidak normal, berarti ada masalah pada jalur kabel. &nbsp;</p>\r\n\r\n<p> 4. Speedometer. Jika semua lolos dan jarum penunjuk masih tak normal. Dipastikan yang rusak bagian speedometer. Ada dua opsi terakhir, memperbaiki atau mengganti dengan baru. Perbaiki jika memungkinkan atau kerusakannya ringan seperti mekanis lengket karena kemasukan air, atau ada kabel yang putus. &nbsp;</p>'),
(11, 'solusiinjeksi', '<h3><b><p>DIAGNOSA KERUSAKAN MELALUI SISTEM INJEKSI<p></b></h3>\r\n<img width=200 height=260 src=''images/injeksi.png'' />\r\n</p></b>&nbsp;</p>\r\n\r\n<p> Untuk mengetahui kerusakan yang terjadi, Anda bisa melakukan penghitungan pada jumlah kedipan yang muncul. Honda sendiri memiliki standar kode yang berupa jumlah dari kedipan MIL tersebut. &nbsp;</p>\r\n<p> saat dihidupkan indikator Harusnya menyala selama 2 detik dan akan mati (kalibrasi) jika tidak maka, &nbsp;</p>\r\n<p> Kerusakan pada sensor injeksi, Pada generasi sebelumnya ada 6 sensor yaitu; Manifold Absolute Pressure (MAP), Intake Air Temperature (IAT), Throttle Position Sensor (TPS), Engine Coolant Temperature (ECT) atau Engine Oil Temperature (EOT), Crankshaft Position (CKP) dan O2 Sensor. Sedang pada generasi terbaru ini MAP dan IAT ditanggalkan, fungsinya digantikan oleh CKP dan O2 Sensor. &nbsp;</p>\r\n\r\n<p> jika tetap menyala normal namun memunculkan kedipan lain maka Berikut arti kedipan dan kode kerusakan pada motor-motor injeksi keluaran Honda : &nbsp;</p>\r\n\r\n<b><p> 1 kedipan &nbsp;</p>\r\n\r\n<p> Kode ini memastikan motor Anda mengalami kerusakan pada Manifold Absolute Pressure (MAP) yang mendeteksi tingkat kevakuman pada intake manifold. &nbsp;</p>\r\n\r\n<b><p> 7 kedipan &nbsp;</p>\r\n\r\n<p> Apabila kode ini muncul, Engine Oli Temperatura atau Engine Coolent Temperature mengalami gangguan. Gangguan ini menyebabkan sistem pembakaran tidak bisa bekerja secara maksimal yang berimbas pada pemborosan bahan bakar. &nbsp;</p>\r\n\r\n<b><p> 8 kedipan &nbsp;</p>\r\n\r\n<p> Kode ini menunjukkan terjadinya gangguan pada sensor Throttle Position. Kerusakan pada sensor tersebut menyebabkan pemborosan bahan bakar dan sulit starter. &nbsp;</p>\r\n\r\n<b><p> 9 kedipan &nbsp;</p>\r\n\r\n<p> Dipastikan Intake Air Temperature Anda mengalami gangguan. IAT sendiri bekerja dengan cara mendeteksi suhu udara yang melewati throttle body, kemudian mengubah suhu menjadi sinyal listrik yang dikirim ke ECU. Dengan adanya sensor IAT, jumlah bahan bakar yang diinjeksikan akan selalu pada tingkat yang optimal. &nbsp;</p>\r\n\r\n<b><p> 12 kedipan &nbsp;</p>\r\n\r\n<p> Kode ini menunjukkan Injector sepeda motor Anda mengalami masalah. Gangguan ini biasanya menyebabkan motor tak bisa dinyalakan. &nbsp;</p>\r\n\r\n<b><p> 21 kedipan &nbsp;</p>\r\n\r\n<p> Gangguan sensor O2 akan diproyeksikan melalui kode ini. Sensor ini sendiri befungsi untuk mendeteksi gas buang terhadap gas-gas beracun dan kondisi pembakaran mesin. &nbsp;</p>\r\n\r\n<b><p> 29 kedipan &nbsp;</p>\r\n\r\n<p> Idle Air Control Valve merupakan komponen yang membantu dalam penyalaan mesin. Apabila kode ini muncul, dipastikan IACV Anda mengalami gangguan. &nbsp;</p>\r\n\r\n<b><p> 33 kedipan &nbsp;</p>\r\n\r\n<p> Apabila Anda mengalami kode ini, dipastikan sepeda motor Anda tidak akan bisa menayala. Pasalnya kode ini mengindikasi bahwa terjadi gangguan pada ECM (Engine Control Module) yang merupakan otak dari seluruh pengaturan sistem injeksi. &nbsp;</p>\r\n\r\n<b><p> 54 kedipan &nbsp;</p>\r\n\r\n<p> Kode ini menunjukkan terjadi kerusakan pada sensor Bank Angle. Sensor ini berfungsi mematikan tenaga ketika mesin mengalami kemiringan mencapai 60 derajat. </p>  &nbsp;</p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE IF NOT EXISTS `pengguna` (
  `id_pengguna` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kelamin` varchar(50) NOT NULL,
  `usia` int(5) NOT NULL,
  `alamat` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `nama`, `kelamin`, `usia`, `alamat`) VALUES
(1, 'fajar', '24bc50d85ad8fa9cda686145cf1f8aca', 'fajar', 'L', 21, 'jambi'),
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', 'P', 21, 'jambi'),
(7, 'ali', '86318e52f5ed4801abe1d13d509443de', 'ali', 'W', 100, 'jambi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tmp_pengguna`
--

CREATE TABLE IF NOT EXISTS `tmp_pengguna` (
  `id` int(20) unsigned NOT NULL,
  `id_log` int(5) NOT NULL,
  `id_pengguna` int(10) NOT NULL,
  `noip` varchar(60) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` varchar(5) CHARACTER SET ascii NOT NULL,
  `username` varchar(15) CHARACTER SET ascii NOT NULL,
  `password` text CHARACTER SET ascii NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`) VALUES
('ID001', 'fajar', '24bc50d85ad8fa9cda686145cf1f8aca'),
('ID003', 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
 ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id_pages`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
 ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `tmp_pengguna`
--
ALTER TABLE `tmp_pengguna`
 ADD UNIQUE KEY `id` (`id`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

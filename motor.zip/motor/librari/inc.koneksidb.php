<?php
	$cn=mysql_connect("localhost","root",""); 
	mysql_select_db("databases_2015_sistempakar_motormatic"); 
//session_start();
/*$my['host']	="localhost";
$my['user']	="root";
$my['pass']	= "";
$my['dbs']	= "databases_2015_sistempakar_motormatic";


$koneksi	= mysql_connect($my['host'], 
							$my['user'], 
							$my['pass']);
if (! $koneksi) {
  echo "Gagal koneksi boss..!";
  mysql_error();
}
mysql_select_db($my['dbs'])
	 or die ("Database nggak ada tuh".mysql_error());
*/
?>
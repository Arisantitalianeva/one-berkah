<?php 
if(!empty($_SESSION['username_pengguna']))
{
	include "DataDiagnosa.php";				
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=kerusakan'>";
}
else
{
	echo '<meta http-equiv="refresh" content="0;url=?page=loginuser">';
}
?>

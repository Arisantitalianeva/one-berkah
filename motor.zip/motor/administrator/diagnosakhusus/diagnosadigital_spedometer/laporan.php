<?php

mysql_connect("localhost", "root", "") or die ("Gagal konek ke server.");
mysql_select_db("databases_2015_sistempakar_motormatic") or die ("Gagal membuka database.");

error_reporting(E_ALL);
ini_set('display_errors', 1);
//include"../akses.php";
//include"session.php";
//include"koneksi.php";
//$startdate =$_POST['startdate'];
//$enddate = $_POST['enddate'];
//$date1 = DateTime::createFromFormat('d-m-Y', $startdate)->format('Y-m-d');
//$date2 = DateTime::createFromFormat('d-m-Y', $enddate)->format('Y-m-d');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Cache-Control: max-age=0");
header("Content-Type: application/force-download");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);
header("Expires,0");
header("Content-disposition:attachment; filename=Laporan".date('d-m-Y').".xls");
echo'<table align="center" border="1"
<thead>
<tr>
    <th style="background: #EEE; font-weight: bold;">ID PENGGUNA</th>
    <th style="background: #EEE; font-weight: bold;">USERNAME</th>
    <th style="background: #EEE; font-weight: bold;">NAMA</th>
    <th style="background: #EEE; font-weight: bold;">JENIS KELAMIN</th>
    <th style="background: #EEE; font-weight: bold;">USIA</th>
    <th style="background: #EEE; font-weight: bold;">ALAMAT</th>
</tr>
</thead>
<tbody>
';
$ambil_data = mysql_query("SELECT * FROM pengguna");
echo '';
$no = 1;
while($data_report=mysql_fetch_array($ambil_data)){
$id_pengguna = $data_report['id_pengguna'];
$username = $data_report['username'];
$nama = $data_report['nama'];
$kelamin =$data_report['kelamin'];
$usia =$data_report['usia'];
$alamat =$data_report['alamat'];
echo'
<tr>
    <td>'.$id_pengguna.'</td>
    <td>'.$username.'</td>
    <td>'.$nama.'</td>
    <td>'.$kelamin.'</td>
    <td>'.$usia.'</td>
    <td>'.$alamat.'</td>    
</tr>
';
}
echo'
</tbody></table>
';

?>
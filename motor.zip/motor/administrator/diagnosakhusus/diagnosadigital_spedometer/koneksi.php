<?php
$host="localhost";
$user="root";
$pass="";
$database="databases_2015_sistempakar_motormatic";
mysql_connect($host,$user,$pass) or die ("server error");
mysql_select_db($database) or die ("database gagal dibuka");
?>


<?php
include "inc.session.php"; 
include "../../../librari/inc.koneksidb.php";
?>

<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html class="no-js"><!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>
    Administrator
  </title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">

  <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700" rel="stylesheet" type="text/css">
  <link href="../../../css/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" id="bootstrap-css">
  <link href="../../../css/adminflare.min.css" media="all" rel="stylesheet" type="text/css" id="adminflare-css">
  </script>
  
  <script src="../../../js/modernizr-jquery.min.js" type="text/javascript"></script>
  <script src="../../../js/adminflare-demo.min.js" type="text/javascript"></script>
  <script src="../../../js/bootstrap.min.js" type="text/javascript"></script>
  <script src="../../../js/adminflare.min.js" type="text/javascript"></script>
  
  <script type="text/javascript">
    $(document).ready(function() {
      prettyPrint();
    });
  </script>

  <style type="text/css">
    .box, .well { padding-bottom: 0; }
  </style>
</head>
<body>
<script type="text/javascript">demoSetBodyLayout();</script>
  <!-- Main navigation bar
    ================================================== -->
  <header class="navbar navbar-fixed-top" id="main-navbar">
    <div class="navbar-inner">
      <div class="container">
       <a class="logo" href="#"><img alt="logo berkah" src="../../../images/logo berkah.png" style="width: 115px; height:auto; margin-top:3px; margin-bottom:5px;"></a>

        <a class="btn nav-button collapsed" data-toggle="collapse" data-target=".nav-collapse">
          <span class="icon-reorder"></span>
        </a>

        <div class="nav-collapse collapse">
          <ul class="nav">
            <li class="divider-vertical"></li>
            <li class="active"><a href="../index.php"><i class="icon-home"></i>BACK DIAGNOSA KHUSUS</a></li>
            <li class="divider-vertical"></li>
            <?php
            if(!empty($_SESSION['username_admin']))
            {
            ?>
            <li class="divider-vertical"></li>
            
            <?php } ?>
          </ul>
          <ul class="nav  pull-right">
            
          </ul>
        </div>
      </div>
    </div>
  </header>
  <!-- / Main navigation bar -->
  
  <!-- Left navigation panel
    ================================================== -->
  <nav id="left-panel">
    <div id="left-panel-content">
    </div>
    <div class="icon-caret-down"></div>
    <div class="icon-caret-up"></div>
  </nav>
  <!-- / Left navigation panel -->
  
  <!-- Page content
    ================================================== -->
  <section class="container">
  
    <!-- Headings
      ================================================== -->
    <section class="row-fluid">
      <h4><span class='icon-leaf'></span> DIAGNOSA rem </h4>
      <div class="box">
        <div class="well">


				
<p>
  <?php
mysql_connect("localhost", "root", "") or die ("Gagal konek ke server.");
mysql_select_db("databases_2015_sistempakar_motormatic") or die ("Gagal membuka database.");
?>
</p>

<table width="1117" height="62" border="5" align="center">
  <tr>
<th width="52" height="26">ID</th>
<th width="629">PERTANYAAN </th>
<th width="87">BENAR</th>
<th width="87">SALAH</th>
<th width="87">MULAI</th>
<th width="103">SELESAI</th>
<th width="87">TAMBAH</th>
<th width="87">EDIT</th>
<th width="103">HAPUS</th>
</tr>
<?php
$query = "select * from diagnosa_rem";
$result = mysql_query($query);
while ($buff = mysql_fetch_array($result)){
?>
<tr>
<td height="20" width="87" align="center" valign="top"><?php echo $buff['ID']; ?></td>
<td width="87" align="center" valign="top"><?php echo $buff['solusi_dan_pertanyaan']; ?></td>
<td width="87" align="center" valign="top"><?php echo $buff['bila_benar']; ?></td>
<td width="87" align="center" valign="top"><?php echo $buff['bila_salah']; ?></td>
<td width="87" align="center" valign="top"><?php echo $buff['mulai']; ?></td>
<td width="87" align="center" valign="top"><?php echo $buff['selesai']; ?></td>
<td width="87" align="center" valign="top"><a href="tambah.php">TAMBAH</a></td>
<td width="87" align="center" valign="top"><a href="edit.php?ID=<?php echo $buff['ID']; ?>">EDIT</a></td>
<td width="87" align="center" valign="top"><a href="hapus.php?ID=<?php echo $buff['ID']; ?>">HAPUS</a></td>
 </tr>
<?php
}
mysql_close();
?>
</table>
<p>&nbsp;</p>
<td><p align="center">&nbsp;</p></td>
 <p><a href="tambah.php"></a>
<td><p align="center"><a href="cari.php"></a> </p></td>

					
					
					
					


<p>&nbsp;</p>
<p>&nbsp;</p>


		
		
		
		
        </div>
      </div>
    </section>
    
    <footer id="main-footer">
      Sistem Pakar Pendeteksi Kerusakan Motor Matic Honda
    </footer>
    <!-- / Page footer -->
  </section>
</body>
</html>

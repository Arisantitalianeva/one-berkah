<?php 
header("Location: http://localhost/phpmyadmin/index.php");
?>
